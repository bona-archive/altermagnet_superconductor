function result=pauli(m)

if m==0
    result=eye(2);
elseif m==1
    result=[0 1 ; 1 0];
elseif m==2
    result=[0 -1i ; 1i 0];
elseif m==3
    result=[1 0 ; 0 -1];
end